package test;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import pages.*;
import utilities.FetchExcel;
import utilities.UtilClass;

/**
 * @author Namitha
 */
public class ProductCheckout extends UtilClass {
    FetchExcel excelData = new FetchExcel();

    /***
     * Description: Initialises Test case and starts reporting
     * Created By: Namitha
     */
    @BeforeSuite
    public void initialiseTest(){
        Setup();
    }

    /***
     * Description: Closes the app and ends reporting
     * Created By: Namitha
     */
    @AfterSuite
    public void AfterTest(){
        closeApp();
        endResult();
    }

    /***
     * Description: Test case to add item to cart in amazon application
     * Created By: Namitha
     */
    @Test
    public void TestCase1() {
        excelData.readData("TestCase1");
        LoginPage loginPage1 = new LoginPage(test);
        loginPage1.validateAndSelectSkipLogin();
        new HomePage(test).searchAndSelectProduct(excelData);
        new LocationDetailPage(test).location_details();
        new ProductDetailsPage(test).verifyProductDetailsAndAddToCart();
        new CartPage(test).cartItem();
    }
}
