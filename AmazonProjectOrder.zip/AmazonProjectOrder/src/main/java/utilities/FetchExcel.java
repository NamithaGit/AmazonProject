package utilities;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Namitha
 */
public class FetchExcel {

    UtilClass utilClass = new UtilClass();
    FileInputStream fis = null;
    XSSFWorkbook wb = null;
    Map<String, String> map = new HashMap<String, String>();

    /***
     * Description: Opens Excel file
     * Created By: Namitha
     */
    public void openExcel() {
        String src = utilClass.readConfigFile("PATH") + "/src/main/resources/TestData/Testdata.xlsx";

        try {
            fis = new FileInputStream(src);
            wb = new XSSFWorkbook(fis);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Assert.assertTrue(false, e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            Assert.assertTrue(false, e.getMessage());
        }
    }

    /**
     * Description: reads Test data from excel sheet
     * Created By: Namitha
     * @param testCaseName : Row where to read test data
     * @return - returns data read from excel
     */
    public void readData(String testCaseName) {

        openExcel();
        XSSFSheet input_Sheet = wb.getSheet("Input");
        Row row = null;
        Row r = input_Sheet.getRow(0);
        int maxCell = r.getLastCellNum();
        int lastRow = input_Sheet.getLastRowNum();
        int rowNum;

        for (rowNum = 1; rowNum <= lastRow; rowNum++) {
            row = input_Sheet.getRow(rowNum);
            if (row.getCell(0).getStringCellValue().equalsIgnoreCase(testCaseName)) {
                break;
            }
        }

        for (int i = 1; i < row.getLastCellNum(); i++) {
            map.put(r.getCell(i).getStringCellValue(), row.getCell(i).getStringCellValue());
        }

        try {
            closeExcel();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
     * Description: Reusable function to fetch the specific testdata
     * Created By: Namitha
     * Attribute: key - column name in the testcase so the corresponding cell value is returned
     */
    public String getValue(String key) {
        return map.get(key);
    }

    /*
     * Description: Reusable function to close excel
     * Created By: Namitha
     */
    public void closeExcel() throws IOException {
        wb.close();
    }
}


