package utilities;

import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static com.aventstack.extentreports.MediaEntityBuilder.createScreenCaptureFromPath;
import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * @author Namitha
 */
public class UtilClass extends ReportClass {

    public static AndroidDriver driver;

    /**
     * Description: Reads data from config file
     * Created by: Namitha
     * @param key : object to read from config file
     * @return : Data read from config file
     */
    public String readConfigFile(String key) {
        Properties p = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + "/Config.properties");
            p.load(fs);
            return (String) p.get(key);
        } catch (IOException e) {
            e.printStackTrace();
            return "unable to read Data";
        }
    }

    /**
     * Description: Launches the application in mobile device
     * Created By: Namitha
     */
    public void Setup() {
        startResult();
        DesiredCapabilities cab = new DesiredCapabilities();

        String os_Type = readConfigFile("OS_TYPE");
        String os_version = readConfigFile("OS_VERSION");
        String device_Name = readConfigFile("DEVICE_NAME");
        String path = readConfigFile("PATH");

        cab.setCapability("platformName", os_Type);
        cab.setCapability("platformVersion", os_version);
        cab.setCapability("app", path + "\\apk\\Amazon_shopping.apk");
        cab.setCapability("appPackage", "com.amazon.mShop.android.shopping");
        cab.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");
        //cab.setCapability("automationName","uiautomator2");

        try {
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), cab);
            driver.manage().timeouts().implicitlyWait(30, SECONDS);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Closes the application
     */
    public void closeApp() {
        driver.quit();
    }

    /**
     * Description: identify element using locator
     * Created By: Namitha
     * @param property : string includes locator and element entity
     * @return : located element
     */
    public AndroidElement getLocator(String property) {
        String locator = property;
        String locatorType = locator.split(">")[0];
        String locatorValue = locator.split(">")[1];
        WebElement locatedEle = null;
        if (locatorType.equalsIgnoreCase("id")) {
            locatedEle = driver.findElement(By.id(locatorValue));
            return (AndroidElement) locatedEle;
        } else if (locatorType.equalsIgnoreCase("xpath")) {
            locatedEle = driver.findElement(By.xpath(locatorValue));
            return (AndroidElement) locatedEle;
        } else {
            locatedEle = driver.findElement(By.name(locatorValue));
            return (AndroidElement) locatedEle;
        }
    }

    /**
     * Description: List of web elements
     * Created by : Namitha
     * @param property : string includes locator and element entity
     * @return : list of elements identified
     */
    public List<AndroidElement> getElements(String property) {
        String locator = property;
        String locatorType = locator.split(">")[0];
        String locatorValue = locator.split(">")[1];
        List<AndroidElement> elements = null;
        if (locatorType.equalsIgnoreCase("id")) {
            elements = driver.findElements(By.id(locatorValue));
            return elements;
        } else if (locatorType.equalsIgnoreCase("xpath")) {
            elements = driver.findElements(By.xpath(locatorValue));
            return elements;
        } else {
            elements = driver.findElements(By.name(locatorValue));
            return elements;
        }
    }

    /**
     * Description: wait for elements to load
     * Created by: Namitha
     */
    public void waitForElement() {
        driver.manage().timeouts().implicitlyWait(30, SECONDS);
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(30, SECONDS)
                .pollingEvery(5, SECONDS)
                .ignoring(NoSuchElementException.class);
    }


    /**
     * Description: wait for element to be clickable
     * Created By: Namitha
     * @param element :  element is clickable
     */
    public void waitForElementClickable(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.elementToBeClickable(element));
        }catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not intractable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not visible","FAIL");
        }
    }

    /**
     * Description: wait for element to be clickable
     * Created By: Namitha
     * @param element : wait for element
     */
    public void waitForElementPresent(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Description: Captured screenshots
     * Created By: Namitha
     * @return : path of screenshot
     */
    public String getScreenshot() {
        File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String screenShotDestination = null;

        FileInputStream fileInputStreamReader = null;
        try {
            fileInputStreamReader = new FileInputStream(sourceFile);
            byte[] bytes = new byte[(int) sourceFile.length()];
            fileInputStreamReader.read(bytes);
            screenShotDestination = readConfigFile("PATH") + "/reports/screenshots/" + System.currentTimeMillis() + ".jpeg";
            File destination = new File(screenShotDestination);
            FileUtils.copyFile(sourceFile, destination);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return screenShotDestination;
    }

    /**
     * Description: Logs to attach in HTML report
     * Created By: Namitha
     * @param message : Message to display in HTML report log
     * @param status : status of execution to display in report
     */
    public void reportLog(String message, String status) {
        if (status.equalsIgnoreCase("INFO")) {
            try {
                MediaEntityModelProvider screenshot = createScreenCaptureFromPath(getScreenshot()).build();
                test.log(Status.INFO, message, screenshot);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (status.equalsIgnoreCase("FAIL")) {
            try {
                test.log(Status.FAIL, message, createScreenCaptureFromPath(getScreenshot()).build());
               } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (status.equalsIgnoreCase("PASS")) {
            try {
                MediaEntityModelProvider screenshot = createScreenCaptureFromPath(getScreenshot()).build();
                test.log(Status.PASS, message, screenshot);
               } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /***
     * Description: Click on Element
     * Created By: Namitha
     * @param property : Property of element to identify
     * @param message : Message to display in HTML report log
     */
    public void elementClick(String property, String message) {
        AndroidElement element = getLocator(property);
        try {
            waitForElementClickable(element);
            element.click();
            System.out.println(message + " element is clicked");
            reportLog(message + " element is clicked", "PASS");
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not intractable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        }
    }

    /**
     * Description: Enter text in text field
     * Created By: Namitha
     * @param property : Property of element to identify
     * @param message : Message to display in HTML report log
     */
    public void enterText(String property, String message) {
        AndroidElement element = getLocator(property);
        try {
            Thread.sleep(5000);
            waitForElement();
            driver.manage().timeouts().implicitlyWait(30, SECONDS);
            element.clear();
            element.sendKeys(message);
            reportLog(message + " is entered", "PASS");
            System.out.println(message + "entered");
        }catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not interactable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        }
    }

    /**
     * Description: Element is Displayed
     * Created By: Namitha
     * @param property : Element id's to check if displayed
     * @param message : Message to display in HTML report log
     */
    public void verifyElementDisplayed(String property, String message) {
        AndroidElement element = getLocator(property);
        try {
            waitForElement();
            element.isDisplayed();
            System.out.println(message + "element is displayed");
            reportLog(message + " element is displayed", "PASS");
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not interactable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        }
    }

    /**
     * Description: Generate a random number and click on respective element
     * Created By: Namitha
     * @param property : Property of element to identify
     * @param message : Message to display in HTML report log
     */
    public void generateAndClickRandom(String property, String message) {
        int ran_Num = 0, ele_Size = 0;
        Random random = new Random();
        WebElement element = null;

        ele_Size = getElements(property).size();
        ran_Num = random.nextInt(ele_Size);
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            element = getElements(property).get(ran_Num);
            element.click();
            reportLog(message + " random element is clicked", "PASS");
            System.out.println(message);
        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not interactable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(message+" element not present","FAIL");
        }
    }

    /**
     * Description: Scroll till particular element
     * Created By: Namitha
     * @param text : Scroll until text is displayed
     */
    public void scrollToElement(String text) {
        try {
            driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"" + text + "\").instance(0))");
            reportLog(text +" element identified","PASS");
        } catch (Exception e){
            Assert.assertTrue(false, e.getMessage());
            reportLog(text +" element not present","FAIL");
        }
    }

    /**
     * Description: Check if element is presentn
     * Created By: Namitha
     * @param property : Property of element to identify
     */
    public boolean verifyElement(String property) {
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        boolean present = true;
        try {
            getLocator(property);
            reportLog("element is present", "PASS");
            return present;
        } catch (Exception e) {
            present = false;
            e.printStackTrace();
            reportLog(" element not present","FAIL");
            return present;
        }
    }
    /**
     * Description: Get text from element
     * Created By: Namitha
     * @param property : Property of element to identify
     */
    public String getText(String property) {
        AndroidElement element = getLocator(property);
        String text = null;
        try {
            text = element.getText();

        } catch (ElementNotVisibleException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not visible","FAIL");
        } catch (ElementNotInteractableException e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not interactable","FAIL");
        } catch (Exception e) {
            Assert.assertTrue(false, e.getMessage());
            reportLog(" element not present","FAIL");
        }
        return text;
    }

}
