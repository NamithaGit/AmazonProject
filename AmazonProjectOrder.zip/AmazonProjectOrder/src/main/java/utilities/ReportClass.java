package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

/***
 * @author Namitha
 */
public class ReportClass {

    public ExtentTest test;
    public static ExtentReports extent;

    /**
     * Description: Starts HTML report
     * Created By: Namitha
     * @return Initializes the extent test report
     */
    public ExtentReports startResult() {
        ExtentHtmlReporter reporter = new ExtentHtmlReporter("./Reports/Result.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
        test = extent.createTest("Amazon order");

        return extent;
    }

    /**
     * Description: ends result
     * Created By: Namitha
     */
    public void endResult() {
        extent.flush();
    }
}
