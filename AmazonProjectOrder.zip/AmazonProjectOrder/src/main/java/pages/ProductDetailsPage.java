package pages;

import com.aventstack.extentreports.ExtentTest;
import utilities.UtilClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class ProductDetailsPage extends UtilClass {

    private static Properties prop;
    private final String path = "//src/main/resources/locators/ProductDetailPage.properties";

    /***
     * Description : constructor to initiate driver and reports
     * Created By: Namitha
     * @param lTest :Class object for HTML report logging
     */
    public ProductDetailsPage(ExtentTest lTest){
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            reportLog("Property File not found","FAIL");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /***
     * Description: Validate Product Detail Page
     * Created By: Namitha
     */
    private void validateProductDetail() {
        verifyElementDisplayed(prop.getProperty("product_Name"), "Product Detail Page ");
    }

    /**
     * Description: Button Add to Cart
     * Created By: Namitha
     */
    private void buttonAddToCart() {
        scrollToElement("Add To Cart");
        elementClick(prop.getProperty("button_addToCart"), "Add to cart button");
    }

    /**
     * Description: Navigate to cart
     * Created By: Namitha
     */
    private void clickOnCartIcon() {
        elementClick(prop.getProperty("cartIcon"), "Cart Icon");
    }

    /**
     * Description: verify Product Detail And Add to cart
     * Created By: Namitha
     */
    public void verifyProductDetailsAndAddToCart() {
        validateProductDetail();
        buttonAddToCart();
        clickOnCartIcon();
    }

}
