package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import utilities.FetchExcel;
import utilities.UtilClass;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/***
 * @author Namitha
 */
public class HomePage extends UtilClass {
    private static Properties prop;
    private final String path = "//src/main/resources/locators/HomePage.properties";

    /***
     * Description: constructor to initiate driver and reports
     * Created By: Namitha
     * @param lTest :Class object for HTML report logging
     */
    public HomePage(ExtentTest lTest){
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            reportLog("Property File not found","FAIL");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Description: Enter product in search bar
     * Created By: Namitha
     */
    private void enterProductToSearch(FetchExcel excelData) {
        elementClick(prop.getProperty("enter_text_to_search"),"Search");
        enterText(prop.getProperty("enter_text_to_search"), excelData.getValue("SearchItem"));
    }

    /**
     * Description: Select random product from search list
     * Created By: Namitha
     */
    private void selectProductFromSearchList() {
        generateAndClickRandom(prop.getProperty("search_Product"), "Random Product selected from search list");
    }

    /**
     * Description: Select random product
     * Created By: Namitha
     */
    private void selectProduct() {
        generateAndClickRandom(prop.getProperty("product_List"), "Random product selected");
    }

    /**
     * Description: Search and select product
     * Created By: Namitha
     */
    public void searchAndSelectProduct(FetchExcel excelData) {
        enterProductToSearch(excelData);
        selectProductFromSearchList();
        selectProduct();
    }
}
