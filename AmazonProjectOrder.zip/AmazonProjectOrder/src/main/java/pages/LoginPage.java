package pages;

import com.aventstack.extentreports.ExtentTest;
import utilities.UtilClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class LoginPage extends UtilClass {
    private static Properties prop;
    private final String path = "//src/main/resources/locators/LoginPage.properties";

    /***
     * Description: constructor to initiate driver and reports
     * Created By: Namitha
     */
    public LoginPage(ExtentTest ltest){
        this.test = ltest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            reportLog("Properties file not found","FAIL");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Description: Validate Amazon Sign In screen
     * Created By: Namitha
     */
    private void validateAmazonSignInScreen() {
        verifyElementDisplayed(prop.getProperty("amazon_Sign_in"), "Amazon Sign In");
    }

    /**
     * Description: Click on Skip Login
     * Created By: Namitha
     */
    private void clickOnSkipLogin() {
        elementClick(prop.getProperty("amazon_skip_sign_in"), "Skip Sign In button");
    }

    /***
     * Description: Validate amazon login screen and skip sign in screen
     * Created By: Namitha
     */
    public void validateAndSelectSkipLogin() {
        validateAmazonSignInScreen();
        clickOnSkipLogin();
    }
}
