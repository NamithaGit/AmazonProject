package pages;

import com.aventstack.extentreports.ExtentTest;
import utilities.UtilClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/***
 * @author Namitha
 */
public class CartPage extends UtilClass {

    private static Properties prop;
    private final String path = "//src/main/resources/locators/CartPage.properties";

    /***
     * Description: constructor to initiate driver and reports
     * Created By: Namitha
     * @param lTest: Class object for HTML report logging
     */
    public CartPage(ExtentTest lTest){
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***
     * Description: validate Product name
     * Created By: Namitha
     */
    private void validateProductName() {
        String product_Name = getText(prop.getProperty("productName"));
    }

    /**
     * Description: Validate quantity of product
     * Created By: Namitha
     */
    private void validateProductCount() {
        String product_Quantity = getText(prop.getProperty("productQuantity"));
    }

    /**
     * Description: Click on proceed to checkout button
     * Created By: Namitha
     */
    private void clickCheckoutButton() {
        elementClick(prop.getProperty("ButtonCheckOut"), "Proceed to Checkout button");
    }

    /**
     * Description: validate cart page and click on proceed to checkout
     * Created By: Namitha
     */
    public void cartItem() {
        validateProductName();
        validateProductCount();
        clickCheckoutButton();
    }
}
