package pages;

import com.aventstack.extentreports.ExtentTest;
import utilities.UtilClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Namitha
 */
public class LocationDetailPage extends UtilClass {

    private static Properties prop;
    private final String path = "//src/main/resources/locators/LocationDetailPage.properties";

    /***
     * Description: constructor to initiate driver and reports
     * Created By: Namitha
     * @param lTest : Class object for HTML report logging
     */
    public LocationDetailPage(ExtentTest lTest){
        this.test = lTest;
        prop = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir") + path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            reportLog("Properties File Not found","FAIL");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***
     * Description: Validate Location Detail Page
     * Created By: Namitha
     */
    private void validateLocationSettings() {
        waitForElement();
        if (verifyElement(prop.getProperty("use_My_Current_location"))) {
            verifyElementDisplayed(prop.getProperty("use_My_Current_location"), "Use my Current location");
            click_Enter_Pincode();
            Enter_Pincode();
        }
    }

    /**
     * Description: click on Use my current location
     * Created By: Namitha
     */
    private void clickUseMyCurrentLocation() {
        elementClick(prop.getProperty("use_My_Current_location"), "Use my Current location");
    }

    /**
     * Description: click on Enter Pincode
     * Created By: Namitha
     */
    private void click_Enter_Pincode() {
        elementClick(prop.getProperty("button_Enter_Pincode"), "Enter Pincode button");
    }

    /**
     * Description: Enter Pin code
     * Created By: Namitha
     */
    private void Enter_Pincode() {
        waitForElementClickable(getLocator(prop.getProperty("button_Enter_Pincode_Apply")));
        elementClick(prop.getProperty("text_Enter_Pincode"),"Text box to enter pincode");
        enterText(prop.getProperty("text_Enter_Pincode"), "560096");
        elementClick(prop.getProperty("button_Enter_Pincode_Apply"), "Apply button");
    }

    /**
     * Description: validate location settings
     * Created By: Namitha
     */
    public void location_details() {
        validateLocationSettings();
    }
}
